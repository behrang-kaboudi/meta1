/*!
 * Stockfish copyright T. Romstad, M. Costalba, J. Kiiski, G. Linscott
 * Nathan Rugg, Chess.com, and other contributors.
 *
 * Based on Stockfish.js by Niklas Fiekas
 * https://github.com/niklasf/stockfish.js
 * <niklas.fiekas@backscattering.de>
 *
 * Multi-variant support by Daniel Dugovic and contributors:
 * https://github.com/ddugovic/Stockfish
 *
 * Released under the GNU General Public License v3.
 *
 */

