// const num2 = require('./indexB');

function test100(p) {
}
var t3 = 100;
test100('asas');
module.exports = t3;
var window;
if ('document' in window) {
    export var t4 = module.exports;
}