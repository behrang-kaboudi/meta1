// const Pgn = require('./indexB');
// console.log('num2', 'dsdssdsd10');

function name(params) {
    // console.log('num2', 'function');
}
module.exports = name;