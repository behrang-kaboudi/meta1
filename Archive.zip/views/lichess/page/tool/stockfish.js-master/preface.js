/*!
 * Stockfish.js (http://github.com/nmrugg/stockfish.js)
 * License: GPL
 */
var Stockfish;
function INIT_ENGINE()
{
var STOCKFISH = function (console, wasmPath, isInitializer)
{
